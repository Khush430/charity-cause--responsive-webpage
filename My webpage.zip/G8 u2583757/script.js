let split = new SplitText("#title");

gsap.from("#woman", {
  scrollTrigger: {
    scrub: true,
  },
  y: 50,
});

gsap.from("#leftplant", {
  scrollTrigger: {
    scrub: true,
  },
  x: -150,
});

gsap.from("#rightplant", {
  scrollTrigger: {
    scrub: true,
  },
  x: 150,
});

gsap.from("#ball", {
  scrollTrigger: {
    scrub: true,
  },
  x: -200,
});

gsap.from("#lifebuoy", {
  scrollTrigger: {
    scrub: true,
  },
  x: 200,
});

gsap
  .timeline({
    scrollTrigger: {
      trigger: ".parallax",
      start: "top 50%",
      end: "bottom top",
      toggleActions: "restart none none reset",
    },
  })
  .from(split.chars, {
    yPercent: -150,
    stagger: 0.05,
    duration: 0.7,
    ease: "back",
  })
  .from(split.chars, { opacity: 0, delay: 0.05, stagger: 0.05, duration: 0.2 }, 0)
  .from("button", { y: 100, opacity: 0, ease: "back", duration: 1 }, "<1");
  $(document).on("click", ".demo_menu-item:not(.js-menuBtn)", function () {
    animating = true;
    var $this = $(this);
    var page = +$this.data("page");
    $(".js-menuBtn").removeClass("js-menuBtn");
    $(".demo_page.active").removeClass("active");
    $this.addClass("js-menuBtn m--btn");
    $(".demo_page-"+page).addClass("active");
    $(".demopage, .demo_menu, .demo__light").removeClass("menu-active");
    $(document).off("click", ".demo_content", closeNotFocusedMenu);
    setTimeout(function() {
        $(".demo_menu")[0].className = $(".demo_menu")[0].className.replace(/\bpage-active-•*\b/gi, "");
        $(".demo_menu").addClass("page-active-"+page);
        animating = false;
    }, 1000);
});
